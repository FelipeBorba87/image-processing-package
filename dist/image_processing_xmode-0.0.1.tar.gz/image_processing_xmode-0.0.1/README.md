# image_processing_xmode

The package image_processing_nazgulll is used to:
	Processing
		- Histogram matching
		- Sctructural similarity
		- Resize image
	Utils:
		- Read image
		- Save image
		- Plot image
		- Plot histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing_xmode

```bash
pip install image_processing_xmode
```

## Author
Felipe

## License
[MIT](https://choosealicense.com/licenses/mit/)